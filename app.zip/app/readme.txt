install these modules

pip install requests
pip3 install beautifulsoup4
pip install pil